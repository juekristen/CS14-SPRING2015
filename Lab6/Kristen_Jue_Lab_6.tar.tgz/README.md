//======================================================
//Name: Kristen Jue
//SID: 861149364
//Date: May 18,2015
//=====================================================
2a. My selection sort is stable because it only swaps if the the current element is 
less than the minimum. 
2b. 
int main()
{
    std::vector <int> p;
    p.push_back(10);
    p.push_back(2);
    p.push_back(10);
    p.push_back(10);
    p.push_back(10);
    
    print(p);
    selectionsort(p);
    print(p);
    //should only be 3 moves
    
    std::vector <int> l;
    l.push_back(0);
    l.push_back(0);
    l.push_back(0);
    
    print(l);
    selectionsort(l);
    print(l)
    //should be 0 moves
    
    return 0;
    
    
}
