//======================================================
//Name: Kristen Jue
//SID: 861149364
//Date: May 18,2015
//=====================================================
#include "selectionsort.h"
#include <vector>

int main()
{
    std::vector <int> k;
    k.push_back(2);
    k.push_back(4);
    k.push_back(5);
    k.push_back(1);
    k.push_back(8);
    k.push_back(9);
    std::cout << "pre:\t";
    print(k);
    selectionsort(k);
    std::cout << "post:\t";
    print(k);
    
    std::vector<int> hola;
    std::cout << "pre:\t";
    print(hola);
    selectionsort(hola);
    std::cout << "post:\t";
    print(hola);
    
    std::vector<std::pair<int,int> >l;
    std::pair<int,int> pairs;
    pairs = std::make_pair(1,2);
    l.push_back(pairs);
    pairs = std::make_pair(3,-1);
    l.push_back(pairs);
    pairs = std::make_pair(-1,3);
    l.push_back(pairs);
    pairs = std::make_pair(0,0);
    l.push_back(pairs); 
    pairs = std::make_pair(2,3);
    l.push_back(pairs);
    pairs = std::make_pair(1,2);
    l.push_back(pairs);
    pairs = std::make_pair(1,-2);
    l.push_back(pairs);
    pairs = std::make_pair(8,10);
    l.push_back(pairs);
    
    std::cout << "pre:\t";
    printOrig(l);
    selectionsort(l);
    std::cout << "post:\t";
    printPair(l);
    
    std::vector<std::pair<int,int> >j;
    pairs = std::make_pair(10,2);
    j.push_back(pairs);
    pairs = std::make_pair(-3,-1);
    j.push_back(pairs);
    pairs = std::make_pair(-8,0);
    j.push_back(pairs);
    pairs = std::make_pair(1,1);
    j.push_back(pairs); 
    pairs = std::make_pair(1,1);
    j.push_back(pairs);
    pairs = std::make_pair(1,1);
    j.push_back(pairs);
    pairs = std::make_pair(0,0);
    j.push_back(pairs);
    pairs = std::make_pair(10,2);
    j.push_back(pairs);
    pairs = std::make_pair(5,5);
    j.push_back(pairs);
    pairs = std::make_pair(5,-5);
    j.push_back(pairs);
    pairs = std::make_pair(0,0);
    j.push_back(pairs);
    pairs = std::make_pair(10,2);
    j.push_back(pairs);
    
    std::cout << "pre:\t";
    printOrig(j);
    selectionsort(j);
    std::cout << "post:\t";
    printPair(j);
    
    std::vector<std::pair<int,int> >q;
    pairs = std::make_pair(-1,3);
    q.push_back(pairs);
    pairs = std::make_pair(0,0);
    q.push_back(pairs);
    pairs = std::make_pair(1,-2);
    q.push_back(pairs);
    pairs = std::make_pair(1,2);
    q.push_back(pairs); 
    pairs = std::make_pair(1,2);
    q.push_back(pairs);
    pairs = std::make_pair(2,3);
    q.push_back(pairs);
    pairs = std::make_pair(3,-1);
    q.push_back(pairs);
    pairs = std::make_pair(8,10);
    q.push_back(pairs);
    
    std::cout << "pre:\t";
    printOrig(q);
    selectionsort(q);
    std::cout << "post:\t";
    printPair(q);
    
    return 0;
 }
