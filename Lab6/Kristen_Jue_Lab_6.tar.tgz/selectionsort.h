//======================================================
//Name: Kristen Jue
//SID: 861149364
//Date: May 18,2015
//Approach: checked if each element was less than the 
//current minimum and if I was then I swaped it with 
//the current location.  then also incremented the
//counter. also printed out the vector two times
//=====================================================
#include <utility>
#include <iostream>
int count=0;
template<typename L>
void selectionsort(L &l)
{
   count = 0;
    for(auto i = l.begin();i != l.end(); ++i)
    {
        auto min = i;
        for(auto g = i+1; g!= l.end();++g)
        {
            if(*min > *g)
            {
                min = g;
            }
        }
        if(*min!=*i)
        {
            count = count + 3;
            std::swap(*min,*i);
        }
        
    }
}
template<typename L>
void print(L &k)
{
    if(k.empty())
    {
        std::cout << std::endl;
        return;
    }
    for(auto j = k.begin();j!= k.end();++j)
    {
        std::cout << *j << ' ';
    }
    std::cout << std::endl;
}

template<typename L>
void printPair(L &k)
{
    if(k.empty())
    {
        std::cout << std::endl;
        return;
    }
    for(auto j = k.begin();j!= k.end();++j)
    {
        std::cout <<"(" << j->first <<"," << j->second << ")" << ' ';
    }
    std::cout << std::endl;
    std::cout<< "0 Copies and " << count << " moves" << std::endl;
}

template<typename L>
void printOrig(L &k)
{
    if(k.empty())
    {
        std::cout << std::endl;
        return;
    }
    for(auto j = k.begin();j!= k.end();++j)
    {
        std::cout <<"(" << j->first <<"," << j->second << ")" << ' ';
    }
    std::cout << std::endl;
}